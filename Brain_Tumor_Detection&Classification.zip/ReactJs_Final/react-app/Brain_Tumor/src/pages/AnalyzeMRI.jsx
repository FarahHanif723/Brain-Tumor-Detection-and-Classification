import { FaBrain } from "react-icons/fa6";
import { useState } from "react";
import PatientInfoCard from "../components/PatientInfoCard";
import UploadImg from "../components/UploadImg";
import Loading from "../components/Loading";
import Result from "../components/Result";
import { useScanHistory } from "../hooks/useScanHistory";

function AnalyzeMRI() {
  const [patient, setPatient] = useState({
    name: "",
    id: "",
    age: "",
    gender: "Male",
    date: "",
    doctor: "",
  });
  const [step, setStep] = useState(0);
  const [file, setFile] = useState(null);   // File object (not blob URL)
  const [result, setResult] = useState(null);

  const  {saveScan} = useScanHistory();

  const handleSaveHistory = async () => {
    await saveScan(patient, result, file);
  };

  return (
    <div className="w-full bg-gray-200 flex flex-col items-center">
      <div className="bg-gray-100 w-300 p-8 rounded-xl shadow-xl mt-10">

        <div className="flex gap-2 items-center ml-7">
          <FaBrain className="text-blue-950 text-2xl" />
          <h2 className="text-2xl font-bold text-blue-950">Analyze MRI Scan</h2>
        </div>
        <p className="mt-2 mb-2 text-gray-600 ml-7">
          AI Powered tumor detection. Educational use only.
        </p>

        <div className="bg-white p-7 px-15 rounded-xl shadow-xl mt-5 mb-10">

          {step === 0 && (
            <PatientInfoCard
              patient={patient}
              setPatient={setPatient}
              setStep={setStep}
            />
          )}

          {step === 1 && (
            <UploadImg
              patient={patient}
              setStep={setStep}
              file={file}
              setFile={setFile}
            />
          )}

          {step === 2 && (
            <Loading
              setStep={setStep}
              file={file}
              setResult={setResult}
            />
          )}

         {step === 3 && (
  <Result
    patient={patient}
    result={result}
    file={file}
    setStep={setStep}
    setFile={setFile}
    setResult={setResult}
    setPatient={setPatient}
    onSaveHistory={handleSaveHistory}  
  />
)}

        </div>
      </div>
    </div>
  );
}

export default AnalyzeMRI;