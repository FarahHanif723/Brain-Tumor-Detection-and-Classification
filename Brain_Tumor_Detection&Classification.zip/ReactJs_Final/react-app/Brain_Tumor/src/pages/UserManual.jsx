import { useState } from "react";
import img3 from "../Image/img3.png";
import img4 from "../Image/img4.jpg";
import { HiCheckCircle, HiXCircle } from "react-icons/hi2";

function UserManual() {
  const [activeTab, setActiveTab] = useState("howToUse");

  return (
    <div className="w-full min-h-screen bg-gray-200 flex justify-center p-4 md:p-6">
      <div className="bg-gray-100 w-full max-w-4xl h-fit my-4 md:my-5 p-5 md:p-10 rounded-xl shadow-xl">

        <h2 className="text-2xl md:text-4xl font-bold text-blue-900 text-center mb-6 md:mb-8">
          User Manual
        </h2>

        {/* Tabs */}
        <div className="flex gap-3 md:gap-6 justify-center mb-6 flex-wrap">
          <button
            onClick={() => setActiveTab("howToUse")}
            className={`px-4 md:px-6 py-2 rounded-t-lg font-semibold transition duration-300 text-sm md:text-base
              ${activeTab === "howToUse"
                ? "bg-blue-900 text-white"
                : "bg-gray-200 text-gray-800 hover:bg-gray-300"
              }`}
          >
            How to Use
          </button>
          <button
            onClick={() => setActiveTab("imageGuideLine")}
            className={`px-4 md:px-6 py-2 rounded-t-lg font-semibold transition duration-300 text-sm md:text-base
              ${activeTab === "imageGuideLine"
                ? "bg-blue-900 text-white"
                : "bg-gray-200 text-gray-800 hover:bg-gray-300"
              }`}
          >
            Image Guideline
          </button>
        </div>

        {/* Tab Content */}
        <div className="bg-white shadow rounded-b-lg">

          {/* How To Use */}
          {activeTab === "howToUse" && (
            <div className="p-5 md:p-10 text-gray-800 space-y-3">
              <h2 className="text-blue-900 font-bold text-xl md:text-2xl mb-2">How To Use</h2>
              <ol className="list-decimal pl-5 space-y-2 text-sm md:text-base text-gray-800">
                <li>Log in using your registered email and password.</li>
                <li>Access the Dashboard to manage MRI scans.</li>
                <li>Click "Upload MRI" and select your image from the device.</li>
                <li>Ensure the image is clear and follows the guidelines.</li>
                <li>The AI model will analyze the scan automatically.</li>
                <li>Check if a tumor is detected and view its type.</li>
                <li>Review the results and any additional details provided.</li>
                <li>Download the report in PDF if needed for reference.</li>
              </ol>
            </div>
          )}

          {/* Image Guidelines */}
          {activeTab === "imageGuideLine" && (
            <div className="p-5 md:p-10 text-gray-800 space-y-2">
              <h2 className="text-blue-900 font-bold text-xl md:text-2xl mb-4">Image Guidelines</h2>
              <ul className="list-disc pl-5 space-y-2 text-sm md:text-base">
                <li>Upload high-quality MRI scans only.</li>
                <li>Images should be in JPG or PNG format.</li>
                <li>Ensure the brain region is clearly visible.</li>
                <li>Remove any background clutter if possible (use transparent or clean background).</li>
                <li>File size should be less than 5MB.</li>
                <li>Avoid uploading images that contain marks, annotations, errors, or any extra objects.</li>
              </ul>

              {/* Image comparison — stacks on mobile, side by side on desktop */}
              <div className="flex flex-col sm:flex-row gap-6 mt-8 items-center justify-center">

                {/* Bad example */}
                <div className="flex flex-col items-center gap-2">
                  <HiXCircle className="text-red-600 w-10 h-10 md:w-14 md:h-14" />
                  <div className="flex flex-col items-center bg-white rounded-lg shadow p-3 w-48 md:w-60">
                    <img src={img3} alt="MRI with marks" className="object-contain w-full" />
                    <p className="text-xs md:text-sm text-center text-blue-900 mt-2">
                      Image with marks / errors
                    </p>
                  </div>
                </div>

                {/* Good example */}
                <div className="flex flex-col items-center gap-2">
                  <HiCheckCircle className="text-green-600 w-10 h-10 md:w-14 md:h-14" />
                  <div className="flex flex-col items-center bg-white rounded-lg shadow p-3 w-48 md:w-60">
                    <img src={img4} alt="Clean MRI" className="object-contain w-full" />
                    <p className="text-xs md:text-sm text-center text-blue-900 mt-2">
                      Image with No marks / errors
                    </p>
                  </div>
                </div>

              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}

export default UserManual;