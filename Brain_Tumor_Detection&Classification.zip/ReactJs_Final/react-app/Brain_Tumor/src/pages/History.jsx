import { FaClockRotateLeft } from "react-icons/fa6";
import { useScanHistory } from "../hooks/useScanHistory";
import HistoryCard from "../components/HistoryCard";
import { FaBrain, FaExclamationTriangle, FaCheckCircle, FaFolderOpen } from "react-icons/fa";

function History() {
  const { history, deleteScan, clearHistory } = useScanHistory();
  const tumorCount = history.filter((r) => r.result?.tumor === "Yes").length;

  return (
    <div className="w-full bg-gray-200 flex flex-col items-center min-h-screen">
      <div className="w-full max-w-5xl p-4 md:p-8 mt-6 md:mt-10 mb-10">
        <div className="bg-gray-100 rounded-xl shadow-xl p-4 md:p-8">

          {/* Header */}
          <div className="flex items-center justify-between mb-1 flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <FaClockRotateLeft className="text-blue-950 text-xl" />
              <h2 className="text-xl md:text-2xl font-bold text-blue-950">Scan History</h2>
            </div>
            {history.length > 0 && (
              <button
                onClick={() => { if (window.confirm("Clear all history?")) clearHistory(); }}
                className="text-xs text-red-400 hover:text-red-600 underline cursor-pointer bg-transparent border-none"
              >
                Clear All
              </button>
            )}
          </div>

          <p className="text-gray-500 text-sm mb-4 md:mb-6">
            {history.length} scan{history.length !== 1 ? "s" : ""} saved
            {tumorCount > 0 && ` · ${tumorCount} tumor detection${tumorCount !== 1 ? "s" : ""}`}
          </p>

          {/* Stats */}
          {history.length > 0 && (
            <div className="grid grid-cols-3 gap-2 md:gap-4 mb-4 md:mb-6 ">
             <StatCard 
                label="Total Scans"  
                value={history.length}              
                icon={<FaBrain className="w-6 h-6 text-blue-500" />} 
                color="blue"  
              />

           <StatCard 
             label="Tumors Found" 
             value={tumorCount}                  
             icon={<FaExclamationTriangle className="w-6 h-6 text-red-500" />} 
             color="red"   
           />

          <StatCard 
            label="Clear Scans"  
            value={history.length - tumorCount} 
           icon={<FaCheckCircle className="w-6 h-6 text-green-500" />} 
            color="green" 
          />
            </div>
          )}

          {/* List */}
          <div className="bg-white rounded-xl shadow-xl p-4 md:p-6 flex flex-col gap-3">
            {history.length === 0 ? (
              <div className="flex flex-col items-center gap-3 py-12 md:py-16 text-center">
                <span className="text-5xl"><FaFolderOpen className="text-xl text-blue-950"/></span>
                <p className="text-slate-500 font-medium">No scans saved yet</p>
                <p className="text-slate-400 text-sm">
                  After analyzing an MRI, click "Save to History"
                </p>
              </div>
            ) : (
              history.map((record) => (
                <HistoryCard key={record.id} record={record} onDelete={deleteScan} />
              ))
            )}
          </div>

        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, icon, color }) {
  const colors = {
    blue:  "bg-blue-50  border-blue-100  text-blue-800",
    red:   "bg-red-50   border-red-100   text-red-800",
    green: "bg-green-50 border-green-100 text-green-800",
  };
  return (
    <div className={`rounded-xl border p-3 md:p-4 text-center flex flex-col items-center justify-center ${colors[color]}`}>
      <p className="text-xl md:text-2xl">{icon}</p>
      <p className="text-xl md:text-2xl font-black mt-1">{value}</p>
      <p className="text-xs font-medium mt-0.5 opacity-70">{label}</p>
    </div>
  );
}

export default History;