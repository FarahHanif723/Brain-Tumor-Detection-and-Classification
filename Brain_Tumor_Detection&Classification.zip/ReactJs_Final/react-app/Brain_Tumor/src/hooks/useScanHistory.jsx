

import { useState, useEffect } from "react";

const API = "http://localhost:8000/api";

export function useScanHistory() {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);

  // App load hone par history fetch karo
  useEffect(() => {
    fetchHistory();
  }, []);

  const fetchHistory = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${API}/scan-history`);
      const data = await res.json();
      // Backend se format map karo
      const mapped = data.map((r) => ({
        id: r.id,
        savedAt: r.saved_at,
        image: r.image_base64,
        patient: {
          name: r.patient_name,
          age: r.patient_age,
          gender: r.patient_gender,
        },
        result: {
          label: r.result_label,
          confidence: r.result_confidence,
          tumor: r.tumor_detected,
        },
      }));
      setHistory(mapped);
    } catch (err) {
      console.error("History fetch error:", err);
      setHistory([]);
    } finally {
      setLoading(false);
    }
  };

  // Naya scan save karo
  const saveScan = (patient, result, imageFile) => {
    return new Promise((resolve) => {
      const saveRecord = async (base64Image) => {
        const record = {
  id: Date.now().toString(),
  saved_at: new Date().toISOString(),
  patient_name: patient?.name || "Unknown",
  patient_age: patient?.age || "",
  patient_gender: patient?.gender || "",
  result_label: result?.label || "",
  result_confidence: result?.confidence || 0,
  tumor_detected: result?.tumor || "No", 
  image_base64: base64Image,
};

        try {
          const res = await fetch(`${API}/scan-history`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(record),
          });
          const saved = await res.json();

          // Local state bhi update karo
          const formatted = {
            id: record.id,
            savedAt: record.saved_at,
            image: base64Image,
            patient,
            result,
          };
          setHistory((prev) => [formatted, ...prev]);
          resolve(formatted);
        } catch (err) {
          console.error("Save error:", err);
          resolve(null);
        }
      };

      if (!imageFile) {
        saveRecord(null);
      } else {
        const reader = new FileReader();
        reader.onload = () => saveRecord(reader.result);
        reader.onerror = () => saveRecord(null);
        reader.readAsDataURL(imageFile);
      }
    });
  };

  // Ek scan delete karo
  const deleteScan = async (id) => {
    try {
      await fetch(`${API}/scan-history/${id}`, { method: "DELETE" });
      setHistory((prev) => prev.filter((r) => r.id !== id));
    } catch (err) {
      console.error("Delete error:", err);
    }
  };

  // Saari history clear karo
  const clearHistory = async () => {
    try {
      await fetch(`${API}/scan-history`, { method: "DELETE" });
      setHistory([]);
    } catch (err) {
      console.error("Clear error:", err);
    }
  };

  return { history, loading, saveScan, deleteScan, clearHistory, fetchHistory };
}