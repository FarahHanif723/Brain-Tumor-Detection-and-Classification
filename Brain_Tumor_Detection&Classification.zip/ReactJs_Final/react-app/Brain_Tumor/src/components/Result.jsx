import { FaLongArrowAltLeft,FaCheckSquare } from "react-icons/fa";

import { useEffect, useRef } from "react";
import ResultHeader from "./ResultHeader";
import ResultTumorCard from "./ResultTumorCard";
import ResultDetailsGrid from "./ResultDetailsGrid";
import ResultActions from "./ResultActions";

function Result({ patient, result, file, setStep, setFile, setResult, setPatient, onSaveHistory }) {
  const previewUrl = file ? URL.createObjectURL(file) : null;
  const savedRef = useRef(false);

  useEffect(() => {
    if (result && onSaveHistory && !savedRef.current) {
      savedRef.current = true;
      onSaveHistory();
    }
  }, [result]);

  const handleNewScan = () => {
    setStep(0);
    setFile(null);
    setResult(null);
    if (setPatient) {
      setPatient({ name: "", id: "", age: "", gender: "Male", date: "", doctor: "" });
    }
  };

  return (
    <div className="flex flex-col gap-5">

      <div className="flex items-center gap-2">
        <h2 className="text-2xl text-blue-950 font-black">Analysis Report</h2>
        <span className="px-2 py-0.5 bg-blue-100 text-blue-700 text-xs font-bold rounded-full">AI</span>
        <span className="px-2 py-0.5 bg-green-100 text-green-700 text-xs font-semibold rounded-full ml-1 flex gap-1 items-center"><FaCheckSquare/> Saved</span>
      </div>

      <ResultHeader patient={patient} />
      <ResultTumorCard result={result} previewUrl={previewUrl} />
      <ResultDetailsGrid result={result} />
      <ResultActions patient={patient} result={result} imageFile={file} />

      <button
        onClick={handleNewScan}
        className=" flex  items-center  gap-2 self-start text-sm text-slate-400 hover:text-blue-900 transition underline underline-offset-2 cursor-pointer bg-transparent border-none"
      >
        <FaLongArrowAltLeft className="text-md"/> Start new scan
      </button>

    </div>
  );
}

export default Result;