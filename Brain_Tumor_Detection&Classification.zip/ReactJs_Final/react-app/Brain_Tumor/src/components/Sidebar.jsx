import { FaBars, FaHome, FaInfoCircle, FaFileAlt, FaKey, FaBrain, FaFileMedical, FaSignOutAlt } from "react-icons/fa";
import { Link, useLocation, useNavigate } from "react-router-dom";

const navItems = [
  { to: "/dashboard",                icon: <FaHome />,        label: "Dashboard" },
  { to: "/analyze-MRI",              icon: <FaBrain />,       label: "Analyze MRI" },
  { to: "/user-manual",              icon: <FaInfoCircle />,  label: "User Manual" },
  { to: "/disclaimer",               icon: <FaFileAlt />,     label: "Disclaimer" },
  { to: "/settings/change-password", icon: <FaKey />,         label: "Change Password" },
  { to: "/history",                  icon: <FaFileMedical />, label: "History" },
];

function Sidebar({ open, setOpen }) {
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = () => {
    sessionStorage.removeItem("user");
    sessionStorage.removeItem("disclaimer_accepted");
    navigate("/login");
  };

  return (
    <div
      className={`
        flex-shrink-0 sticky top-0 h-screen
        bg-blue-950 text-white
        flex flex-col px-2 pt-5
        overflow-hidden
        transition-all duration-300
        ${open
          ? "w-36 md:w-56"   // mobile: 144px — desktop: 224px
          : "w-12 md:w-16"   // mobile: 48px  — desktop: 64px
        }
      `}
    >
      {/* Toggle Button */}
      <button
        onClick={() => setOpen(!open)}
        className="hover:bg-gray-200 hover:text-blue-950 p-2 rounded w-fit mb-4 cursor-pointer"
      >
        <FaBars className="text-xl md:text-3xl" />
      </button>

      {/* Nav Items */}
      <ul className="flex flex-col gap-3 flex-1">
        {navItems.map(({ to, icon, label }) => {
          const isActive = location.pathname === to;
          return (
            <li key={to}>
              <Link
                to={to}
                onClick={() => setOpen(false)}
                className={`
                  flex items-center gap-2 p-2 px-2 rounded
                  transition-colors duration-150
                  ${isActive
                    ? "bg-white text-blue-950"
                    : "hover:bg-gray-200 hover:text-blue-950"
                  }
                `}
              >
                <span className="text-lg md:text-xl flex-shrink-0">{icon}</span>
                {open && (
                  <span className="whitespace-nowrap text-xs md:text-base truncate">
                    {label}
                  </span>
                )}
              </Link>
            </li>
          );
        })}
      </ul>

      {/* Logout */}
      <div className="mb-6">
        <button
          onClick={handleLogout}
          className="flex items-center gap-2 w-full p-2 px-2 rounded hover:bg-red-500 hover:text-white transition-colors duration-150 cursor-pointer"
        >
          <span className="text-lg md:text-xl flex-shrink-0"><FaSignOutAlt /></span>
          {open && (
            <span className="whitespace-nowrap text-xs md:text-base">Logout</span>
          )}
        </button>
      </div>

    </div>
  );
}

export default Sidebar;
