import { FaExclamationTriangle,FaCheckSquare } from "react-icons/fa";

function ConfidenceRing({ value = 0, color }) {
  const r = 36;
  const circ = 2 * Math.PI * r;
  const offset = circ - (value / 100) * circ;

  return (
    <svg width="96" height="96">
      <circle cx="48" cy="48" r={r} fill="none" stroke="#e2e8f0" strokeWidth="8" />
      <circle
        cx="48" cy="48" r={r}
        fill="none"
        stroke={color}
        strokeWidth="8"
        strokeDasharray={circ}
        strokeDashoffset={offset}
        strokeLinecap="round"
        transform="rotate(-90 48 48)"
        style={{ transition: "stroke-dashoffset 1s ease" }}
      />
      <text
        x="48" y="52"
        textAnchor="middle"
        dominantBaseline="middle"
        fill={color}
        fontSize="14"
        fontWeight="700"
      >
        {value}%
      </text>
    </svg>
  );
}

function ResultTumorCard({ result, previewUrl }) {
  const tumorFound = result?.tumor === "Yes";

  // const ringColor = tumorFound
  //   ? result?.severity === "High"     ? "#dc2626"
  //   : result?.severity === "Moderate" ? "#ea580c"
  //                                     : "#ca8a04"
  //   : "#16a34a";
            let ringColor;
          if (!tumorFound) {
            ringColor = "#16a34a"; // green
          } else if (result.severity === "High") {
            ringColor = "#dc2626"; // red
          } else if (result.severity === "Moderate") {
            ringColor = "#ea580c"; // orange
          } else {
            ringColor = "#ca8a04"; // yellow
          }

  return (
    <div className={`rounded-2xl border-2 p-5 flex gap-5 items-center
      ${tumorFound
        ? "border-red-200 bg-gradient-to-br from-red-50 to-orange-50"
        : "border-green-200 bg-gradient-to-br from-green-50 to-emerald-50"
      }`}
    >
      {/* MRI thumbnail */}
      {previewUrl && (
        <div className="w-24 h-24 rounded-xl overflow-hidden border-2 border-white shadow-md flex-shrink-0 bg-black">
          <img src={previewUrl} alt="MRI" className="w-full h-full object-contain" />
        </div>
      )}

      {/* Text */}
      <div className="flex-1 min-w-0">
        <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-bold mb-2
          ${tumorFound ? "bg-red-100 text-red-700" : "bg-green-100 text-green-700"}`}
        >
          {tumorFound ? (
            <span className="flex items-center gap-2">
                   <FaExclamationTriangle className="text-orange-600" />
                  Tumor Detected
                </span>
              ) : (
                <span className="flex items-center gap-2">
                   <FaCheckSquare  className="text-green-700" /> 
                   No Tumor Detected"
                </span>
                
              )}
        </div>
        <h3 className={`text-xl font-black tracking-tight ${tumorFound ? "text-red-800" : "text-green-800"}`}>
          {result?.type || "—"}
        </h3>
        <p className="text-sm text-slate-500 mt-0.5">
          {tumorFound ? "Abnormal mass identified in scan" : "No abnormal mass detected"}
        </p>
      </div>

      {/* Confidence ring */}
      <div className="flex flex-col items-center gap-1 flex-shrink-0">
        <ConfidenceRing value={result?.confidence ?? 0} color={ringColor} />
        <p className="text-xs text-slate-400 font-medium">Confidence</p>
      </div>
    </div>
  );
}

export default ResultTumorCard;