import { useEffect, useState } from "react";

function Loading({ setStep, file, setResult }) {
  const [statusMsg, setStatusMsg] = useState("Preparing image...");

  useEffect(() => {
    const analyze = async () => {
      //agr sab theek chale ga to yeah wala code chale ga. Try wala
      try {
        
        setStatusMsg("Sending to AI model...");

        
        const formData = new FormData();
        formData.append("file", file);

        const response = await fetch("http://localhost:8000/analyze", {
          method: "POST",
          body: formData,
        });

        if (!response.ok) throw new Error("Server error");

        const data = await response.json();
        setResult(data);
        setStep(3);

      } catch (err) {
        console.error("Analysis failed:", err);
        setResult({
          tumor:      "Unknown",
          type:       "Analysis failed",
          confidence: 0,
          location:   "N/A",
          severity:   "N/A",
          notes:      "Could not connect to the backend. Check if the FastAPI server is running.",
        });
        setStep(3);
      }
    };

    analyze();
  }, []);

  return (
    <div className="flex flex-col items-center gap-4 py-20">
      <span className="text-5xl animate-spin inline-block">🧠</span>
      <p className="text-lg font-bold text-blue-950">Analyzing MRI Scan...</p>
      <p className="text-sm text-gray-400">{statusMsg}</p>
    </div>
  );
}

export default Loading;