import { FaBrain, FaArrowRight } from "react-icons/fa6";

function PatientInfoCard({ patient, setPatient, setStep }) {
  const handleInput = (e) => {
    setPatient({ ...patient, [e.target.name]: e.target.value });
  };

  // sirf yeah 3 fields zaruri hain jab tak yeah na ho button disabled rhega
  const isValid = patient.name.trim() && patient.age && patient.date;//trim() space remove krta hain.

  return (
    <>
      <h2 className="text-xl font-bold text-blue-950">Patient Information</h2>
      <form className="p-3">
        {/* Name, ID */}
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-md font-semibold text-slate-500 mb-1.5">Full Name *</label>
            <input
              type="text" name="name"
              className="p-2 rounded outline-0 bg-gray-200 w-full hover:ring-2 hover:ring-blue-800 hover:bg-gray-100"
              placeholder="Enter Name"
              value={patient.name} onChange={handleInput}
            />
          </div>
          <div>
            <label className="block text-md font-semibold text-slate-500 mb-1.5">Patient ID</label>
            <input
              name="id"
              placeholder="Enter ID"
              value={patient.id} onChange={handleInput}
              className="p-2 rounded outline-0 w-full bg-gray-200 hover:ring-2 hover:ring-blue-800 hover:bg-gray-100"
            />
          </div>
        </div>

        {/* Age, Gender, Date */}
        <div className="grid grid-cols-3 gap-4 mb-4">
          <div>
            <label className="block text-md font-semibold text-slate-500 mb-1.5">Age *</label>
            <input
              name="age" type="number"
              value={patient.age} onChange={handleInput}
              className="p-2 rounded outline-0 bg-gray-200 w-full hover:ring-2 hover:ring-blue-800 hover:bg-gray-100"
              placeholder="Enter Age"
            />
          </div>
          <div>
            <label className="block text-md font-semibold text-slate-500 mb-1.5">Gender</label>
            <select
              name="gender" value={patient.gender} onChange={handleInput}
              className="p-2 rounded outline-0 w-full bg-gray-200 hover:ring-2 hover:ring-blue-800 hover:bg-gray-100"
            >
              <option>Male</option>
              <option>Female</option>
            </select>
          </div>
          <div>
            <label className="block text-md font-semibold text-slate-500 mb-1.5">Date *</label>
            <input
              name="date" type="date"
              value={patient.date} onChange={handleInput}
              className="p-2 w-full rounded outline-0 bg-gray-200 hover:ring-2 hover:ring-blue-800 hover:bg-gray-100"
            />
          </div>
        </div>

        {/* Referring Doctor */}
        <div className="mb-2">
          <label className="block text-md font-semibold text-slate-500 mb-1.5">Referring Doctor</label>
          <input
            name="doctor" type="text"
            value={patient.doctor} onChange={handleInput}
            className="p-2 rounded outline-0 w-full bg-gray-200 hover:ring-2 hover:ring-blue-800 hover:bg-gray-100"
            placeholder="Referral Doctor Name (Optional)"
          />
        </div>

        

        <div className="flex justify-end">
          <button
            onClick={() => setStep(1)}
            type="button"
            //agr isValid me value hain to wo true nahi to false. isValid ki value agr true hoto button disabled rahe ga false ho to enable.
            //yaha !isValid use kre ge agr fasle hoga to true and agr true hoga to false
            disabled={!isValid}
            className={`flex items-center justify-center gap-2 p-3 px-10 mt-6 rounded-lg shadow outline-0 text-white text-md font-semibold transition duration-300 active:scale-95
              ${isValid
                ? "bg-blue-950 hover:bg-blue-900 shadow-blue-900 hover:shadow-xl cursor-pointer"
                : "bg-blue-950 opacity-40 cursor-not-allowed"
              }`}
          >
            Next : Upload MRI
            <FaArrowRight />
          </button>
        </div>
      </form>
    </>
  );
}

export default PatientInfoCard;