# main.py
from fastapi import FastAPI, File, UploadFile, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List
from PIL import Image
import numpy as np
import tensorflow as tf
import io
from datetime import datetime

# Import database helpers
from database import get_db, hash_password, init_db

# ---------------- FastAPI app and CORS ----------------
app = FastAPI(title="Brain Tumor Detection API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------- Initialize DB on Startup ----------------
@app.on_event("startup")
def startup_event():
    init_db()
    print("Database initialized.")

# ---------------- Load ML Model ----------------
model = tf.keras.models.load_model("Model/4Types_Brain.keras")

CLASS_NAMES = ["glioma", "meningioma", "notumor", "pituitary"]

SEVERITY_MAP = {
    "glioma":     "High",
    "meningioma": "Moderate",
    "pituitary":  "Low",
    "notumor":    "N/A",
}

LOCATION_MAP = {
    "glioma":     "Cerebral hemispheres",
    "meningioma": "Meninges (brain lining)",
    "pituitary":  "Pituitary gland (base of brain)",
    "notumor":    "N/A",
}

NOTES_MAP = {
    "glioma":     "Glioma arises from glial cells and can vary widely in grade and aggressiveness.",
    "meningioma": "Meningioma is typically benign and grows slowly from the meninges.",
    "pituitary":  "Pituitary tumors are usually benign adenomas affecting hormone regulation.",
    "notumor":    "No abnormal mass detected in the scan.",
}

# ---------------- Pydantic Models ----------------
class LoginRequest(BaseModel):
    email: str
    password: str

class ChangePasswordRequest(BaseModel):
    email: str
    old_password: str
    new_password: str

class ScanRecord(BaseModel):
    id: str
    patient_name: str
    patient_age:       Optional[str]   = ""
    patient_gender:    Optional[str]   = ""
    result_label:      Optional[str]   = ""
    result_confidence: Optional[float] = 0.0
    result_severity:   Optional[str]   = ""
    result_location:   Optional[str]   = ""
    result_notes:      Optional[str]   = ""
    tumor_detected:    Optional[str]   = ""
    image_base64:      Optional[str]   = None
    saved_at:          Optional[str]   = ""

# ---------------- ML Endpoint ----------------
@app.post("/analyze")
async def analyze(file: UploadFile = File(...)):
    contents = await file.read()
    img = Image.open(io.BytesIO(contents)).convert("RGB")
    img = img.resize((224, 224))
    img_array = np.expand_dims(np.array(img) / 255.0, axis=0)
    predictions = model.predict(img_array)
    predicted_index = int(np.argmax(predictions[0]))
    confidence = float(np.max(predictions[0])) * 100
    tumor_type = CLASS_NAMES[predicted_index]

    # FIX: was checking "No Tumor" but CLASS_NAMES uses "notumor"
    return {
        "tumor": "No" if tumor_type == "notumor" else "Yes",
        "type": tumor_type,
        "confidence": round(confidence, 1),
        "severity": SEVERITY_MAP[tumor_type],
        "location": LOCATION_MAP[tumor_type],
        "notes": NOTES_MAP[tumor_type],
    }

# ---------------- Auth Endpoints ----------------
@app.post("/api/login")
def login(data: LoginRequest, db=Depends(get_db)):
    cursor = db.cursor()
    cursor.execute(
        "SELECT * FROM users WHERE email=? AND password=?",
        (data.email, hash_password(data.password)),
    )
    user = cursor.fetchone()
    if not user:
        raise HTTPException(status_code=401, detail="Invalid email or password!")
    return {"success": True, "user": {"id": user["id"], "email": user["email"]}}

@app.post("/api/change-password")
def change_password(data: ChangePasswordRequest, db=Depends(get_db)):
    cursor = db.cursor()
    cursor.execute(
        "SELECT * FROM users WHERE email=? AND password=?",
        (data.email, hash_password(data.old_password)),
    )
    user = cursor.fetchone()
    if not user:
        raise HTTPException(status_code=401, detail="Old password incorrect")
    cursor.execute(
        "UPDATE users SET password=? WHERE email=?",
        (hash_password(data.new_password), data.email),
    )
    db.commit()
    return {"success": True, "message": "Password changed successfully"}

# ---------------- Scan History Endpoints ----------------
@app.post("/api/scan-history")
def save_scan(record: ScanRecord, db=Depends(get_db)):
    cursor = db.cursor()
    cursor.execute(
        """
        INSERT OR REPLACE INTO scan_history
        (id, patient_name, patient_age, patient_gender,
         result_label, result_confidence, result_severity,
         result_location, result_notes, tumor_detected,
         image_base64, saved_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            record.id,
            record.patient_name,
            record.patient_age,
            record.patient_gender,
            record.result_label,
            record.result_confidence,
            record.result_severity,
            record.result_location,
            record.result_notes,
            record.tumor_detected,
            record.image_base64,
            record.saved_at or datetime.now().isoformat(),
        ),
    )
    db.commit()
    return {"success": True, "message": "Scan saved successfully!", "id": record.id}

@app.get("/api/scan-history", response_model=List[ScanRecord])
def get_all_scans(db=Depends(get_db)):
    cursor = db.cursor()
    cursor.execute("SELECT * FROM scan_history ORDER BY saved_at DESC")
    rows = cursor.fetchall()
    return [dict(row) for row in rows]

@app.delete("/api/scan-history/{scan_id}")
def delete_scan(scan_id: str, db=Depends(get_db)):
    cursor = db.cursor()
    cursor.execute("DELETE FROM scan_history WHERE id=?", (scan_id,))
    db.commit()
    if cursor.rowcount == 0:
        raise HTTPException(status_code=404, detail="Scan record not found!")
    return {"success": True, "message": "Scan deleted successfully!"}

@app.delete("/api/scan-history")
def clear_all_scans(db=Depends(get_db)):
    cursor = db.cursor()
    cursor.execute("DELETE FROM scan_history")
    db.commit()
    return {"success": True, "message": "All scan history cleared!"}

# ---------------- Run ----------------
# uvicorn main:app --reload --port 8000