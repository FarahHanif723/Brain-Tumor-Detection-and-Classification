# database.py
import sqlite3
import hashlib

DB_NAME = "brain_tumor.db"

# Password hash function
def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

# Database connection generator
def get_db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()

# Initialize database (create tables + default user)
def init_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    # Users table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            email      TEXT    UNIQUE NOT NULL,
            password   TEXT    NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Scan history table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS scan_history (
            id                TEXT PRIMARY KEY,
            patient_name      TEXT NOT NULL,
            patient_age       TEXT,
            patient_gender    TEXT,
            result_label      TEXT,
            result_confidence REAL,
            result_severity   TEXT,
            result_location   TEXT,
            result_notes      TEXT,
            tumor_detected    TEXT,
            image_base64      TEXT,
            saved_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Insert default admin user if not exists
    cursor.execute("SELECT * FROM users WHERE email = ?", ("admin123@gmail.com",))
    if not cursor.fetchone():
        cursor.execute(
            "INSERT INTO users (email, password) VALUES (?, ?)",
            ("admin123@gmail.com", hash_password("admin123"))
        )
        print("Default admin user created.")

    conn.commit()
    conn.close()

# Run once to setup DB
if __name__ == "__main__":
    init_db()
    print("Database initialized successfully!")